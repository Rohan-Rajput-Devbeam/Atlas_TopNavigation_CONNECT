/* tslint:disable */
require("./AtlasNavigationConnect.module.css");
const styles = {
  languageModal: 'languageModal_1a3fedc7',
  NoPermissionModal: 'NoPermissionModal_1a3fedc7',
  selectLang: 'selectLang_1a3fedc7',
  settingBtn: 'settingBtn_1a3fedc7',
  atlasNavigationConnect: 'atlasNavigationConnect_1a3fedc7',
  container: 'container_1a3fedc7',
  navDropDown: 'navDropDown_1a3fedc7',
  navLogo: 'navLogo_1a3fedc7',
  navLink: 'navLink_1a3fedc7'
};

export default styles;
/* tslint:enable */