/* tslint:disable */
require("./NoPermission.css");
const styles = {

};

export default styles;
/* tslint:enable */