declare interface IAtlasNavigationConnectWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'AtlasNavigationConnectWebPartStrings' {
  const strings: IAtlasNavigationConnectWebPartStrings;
  export = strings;
}
