import { WebPartContext } from "@microsoft/sp-webpart-base";
import "isomorphic-fetch";
export declare class SPService {
    private context;
    private userIDinPreferenceList;
    constructor(context: WebPartContext);
    getCurrentUser(): Promise<import("@pnp/sp/site-users/types").ISiteUserInfo>;
    getUserGroups(): Promise<void>;
    getRootOwners(): Promise<any>;
    getUserLanguage(listName: string, userEmail: string): Promise<any[]>;
    getUserBrandView(listName: string, userEmail: string): Promise<any[]>;
    getUniqueLanguages(listName: string): Promise<any[]>;
    getUniqueBrandView(listName: string): Promise<any[]>;
    getToolboxItems(): Promise<any[]>;
    addListItem(listName: string, userEmail: string, selectedLang: string, selectedBrandView: string): Promise<"Item Added Successfully" | "Item Couldn't Be Added">;
    updateListItem(listName: string, selectedLang: string, selectedBrandView: string): Promise<"Item Updated Successfully" | "Item Couldn't Be Updated">;
    private filesave;
    deleteProgram(id: number): Promise<void>;
}
//# sourceMappingURL=SPServices.d.ts.map