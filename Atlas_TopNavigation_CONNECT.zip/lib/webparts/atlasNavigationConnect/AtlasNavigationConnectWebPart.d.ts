import { Version } from '@microsoft/sp-core-library';
import { IPropertyPaneConfiguration } from '@microsoft/sp-property-pane';
import { BaseClientSideWebPart } from '@microsoft/sp-webpart-base';
export interface IAtlasNavigationConnectWebPartProps {
    people: any;
    description: string;
}
export default class AtlasNavigationConnectWebPart extends BaseClientSideWebPart<IAtlasNavigationConnectWebPartProps> {
    render(): void;
    protected onDispose(): void;
    protected get dataVersion(): Version;
    protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration;
}
//# sourceMappingURL=AtlasNavigationConnectWebPart.d.ts.map