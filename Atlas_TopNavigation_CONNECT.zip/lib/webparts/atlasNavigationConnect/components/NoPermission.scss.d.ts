declare const styles: {};
export default styles;
//# sourceMappingURL=NoPermission.scss.d.ts.map