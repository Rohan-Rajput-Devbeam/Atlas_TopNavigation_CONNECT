import * as React from "react";
import './LanguageModal.css';
export declare class LanguageModal extends React.Component<any, any> {
    constructor(props: any);
    changeValue(event: any): void;
    changeValue1(event: any): void;
    render(): JSX.Element;
}
//# sourceMappingURL=LanguageModal.d.ts.map