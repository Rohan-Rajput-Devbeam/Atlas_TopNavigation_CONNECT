declare const styles: {
    languageModal: string;
    NoPermissionModal: string;
    selectLang: string;
    settingBtn: string;
    atlasNavigationConnect: string;
    container: string;
    navDropDown: string;
    navLogo: string;
    navLink: string;
};
export default styles;
//# sourceMappingURL=AtlasNavigationConnect.module.scss.d.ts.map