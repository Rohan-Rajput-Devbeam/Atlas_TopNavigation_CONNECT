import * as React from 'react';
import { IAtlasNavigationConnectProps } from './IAtlasNavigationConnectProps';
import 'bootstrap/dist/css/bootstrap.css';
import 'bootstrap/dist/css/bootstrap.css';
export interface IAtlasNavigationConnectState {
    listName: string;
    user: any;
    userLanguage: string;
    userBrandView: string;
    uniqueLanguages: any;
    uniqueBrandViews: any;
    isNewUser: boolean;
    toolboxItems: any;
    modalShow: boolean;
    user1: any;
    userLanguage1: string;
    userBrandView1: string;
    uniqueLanguages1: any;
    uniqueBrandViews1: any;
    isNewUser1: boolean;
    displayFlag: boolean;
    currUserGroups: any;
    currentUserEmail: string;
    cuurentUserID: any;
    currentUserName: string;
    currUserInitials: string;
    modalShow1: boolean;
    rootOwnerGroups: any;
    displaySiteContent: boolean;
    searchStr: any;
}
export default class AtlasNavigationConnect extends React.Component<IAtlasNavigationConnectProps, IAtlasNavigationConnectState> {
    private SPService;
    constructor(props: any);
    componentDidMount(): void;
    getCurrentUser(): Promise<void>;
    categorizeGroups(): Promise<void>;
    getUserGroups2(): Promise<void>;
    getRootOwners(): Promise<void>;
    onSearch(event: any): void;
    handleKeyPress(e: any): void;
    handleSubmit(selectedLang: string, selectedBrandView: string): Promise<void>;
    setModalShow(): void;
    setModalShow1(): void;
    getToolboxItems(): Promise<void>;
    getUserBrandView(): Promise<void>;
    getUniqueBrandView(): Promise<void>;
    getUserLanguage(): Promise<void>;
    getUniqueLanguages(): Promise<void>;
    render(): React.ReactElement<IAtlasNavigationConnectProps>;
}
//# sourceMappingURL=AtlasNavigationConnect.d.ts.map