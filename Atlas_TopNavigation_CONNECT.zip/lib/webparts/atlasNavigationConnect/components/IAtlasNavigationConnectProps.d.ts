import { WebPartContext } from "@microsoft/sp-webpart-base";
export interface IAtlasNavigationConnectProps {
    description: string;
    context: WebPartContext;
    people: any;
}
//# sourceMappingURL=IAtlasNavigationConnectProps.d.ts.map