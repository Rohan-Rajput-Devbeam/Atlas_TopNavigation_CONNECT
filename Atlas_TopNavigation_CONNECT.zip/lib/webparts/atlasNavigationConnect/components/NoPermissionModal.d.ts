import * as React from "react";
import './NoPermissionModal.css';
export declare class NoPermissionModal extends React.Component<any, any> {
    constructor(props: any);
    render(): JSX.Element;
}
//# sourceMappingURL=NoPermissionModal.d.ts.map